﻿using Blood_Bank_Mangement_System.BLL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blood_Bank_Mangement_System.DAL
{
    class UserDAL
    {
          #region Select Data From Database

        public DataTable Select()
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();
            DataTable dt = new DataTable();

            try
            {
                string sql = "Select *From Tbl_user";
                SqlCommand cmd = new SqlCommand(sql,conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
               
                adapter.Fill(dt);



            }
            //For Exceptiopnal Error
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            return dt;
        }

        #endregion

        #region insert data into database for User Module

        public bool Insert(UsersBBL u)
        {
            bool isSuccess = false;

            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();
            try
            {
                //creating string value to insert data

                string sql = "insert into Tbl_user(User_name,Email,Password,Full_name,Contact,Address,Added_date,Image_name) Values (@User_name,@Email,@Password,@Full_name,@Contact,@Address,@Added_date,@Image_name)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@User_name",u.User_name);
                cmd.Parameters.AddWithValue("@Email",u.Email);
                cmd.Parameters.AddWithValue("@Password",u.Password);
                cmd.Parameters.AddWithValue("@Full_name",u.Full_name);
                cmd.Parameters.AddWithValue("@Contact",u.Contact);
                cmd.Parameters.AddWithValue("@Address",u.Address);
                cmd.Parameters.AddWithValue("@Added_date",u.Added_date);
                cmd.Parameters.AddWithValue("@Image_name",u.Image_name);

               

                int rows = cmd.ExecuteNonQuery();
             
                //row value will be greater than zero if it execute succesfully

                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            return isSuccess;
        }

        #endregion

        #region Update data in database 
        public bool Update(UsersBBL u)
        {
            bool isSuccess = false;
            SqlConnection conn= new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();

            try
            {
                string sql = "update Tbl_user set User_name=@User_name,Email=@Email,Password=@Password,Full_name=@Full_name,Contact=@Contact,Address=@Address,Added_date=@Added_date,Image_name=@Image_name where User_id=@User_id";         
                 SqlCommand cmd = new SqlCommand(sql,conn);

                cmd.Parameters.AddWithValue("@User_name", u.User_name);
                cmd.Parameters.AddWithValue("@Email", u.Email);
                cmd.Parameters.AddWithValue("@Password", u.Password);
                cmd.Parameters.AddWithValue("@Full_name", u.Full_name);
                cmd.Parameters.AddWithValue("@Contact", u.Contact);
                cmd.Parameters.AddWithValue("@Address", u.Address);
                cmd.Parameters.AddWithValue("@Added_date", u.Added_date);
                cmd.Parameters.AddWithValue("@Image_name", u.Image_name);
                cmd.Parameters.AddWithValue("@User_id", u.User_id);

                int rows = cmd.ExecuteNonQuery();
                //row value will be greater than zero if it execute succesfully

                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            return isSuccess;
        }
        #endregion

        #region Delete data from database 

        public bool Delete(UsersBBL u)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();
            try
        {
                string sql = "Delete from Tbl_user where User_id = @User_id";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@User_id", u.User_id);


                int rows = cmd.ExecuteNonQuery();
                //row value will be greater than zero if it execute succesfully

                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
          catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            return isSuccess;
        }
        #endregion
        #region search the data from database
        public DataTable Search(string keywords)
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();

            DataTable dt = new DataTable();

            try
            {
                string sql = "select *from Tbl_user where User_id Like '%" + keywords + "%' OR Full_name Like '%" + keywords + "%' OR Address Like '%" + keywords + "%'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);

            }

          catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            return dt;
    }

        #endregion
        #region

        public UsersBBL GetIDofUser(string User_name)
        {
            UsersBBL u = new UsersBBL();

            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();


            DataTable dt = new DataTable();

            try
            {
                string sql = "select User_id from Tbl_user where User_name ='" + User_name + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);
                if(dt.Rows.Count>0)
                {
                    u.User_id = int.Parse(dt.Rows[0]["User_id"].ToString());
                }

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            return u;
        }
        #endregion













    }
}
