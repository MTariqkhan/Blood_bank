﻿using Blood_Bank_Mangement_System.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blood_Bank_Mangement_System.DAL
{
    class DonorDAL
    {
        #region Select Data From Database

        public DataTable Select()
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();
            DataTable dt = new DataTable();

            try
            {
                string sql = "Select *From Tbl_Donors";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                adapter.Fill(dt);



            }
            //For Exceptiopnal Error
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            return dt;
        }

        #endregion

        #region insert data into database for Donor Module

        public bool Insert(DonorBLL d)
        {
            bool isSuccess = false;

            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();
            try
            {
                //creating string value to insert data

                string sql = "insert into Tbl_Donors(First_name,Last_name,Email,Contact,Gender,Address,blood_group,Added_date,image_name,Added_by) Values (@First_name,@Last_name,@Email,@Contact,@Gender,@Address,@blood_group,@Added_date,@image_name,@Added_by)";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Last_name", d.Last_name);
                cmd.Parameters.AddWithValue("@Email", d.Email);
                cmd.Parameters.AddWithValue("@Added_by", d.Added_by);
                cmd.Parameters.AddWithValue("@First_name", d.First_name);
                cmd.Parameters.AddWithValue("@Contact", d.Contact);
                cmd.Parameters.AddWithValue("@Gender", d.Gender);
                cmd.Parameters.AddWithValue("@Address", d.Address);
                cmd.Parameters.AddWithValue("@Added_date", d.Added_date);
                cmd.Parameters.AddWithValue("@blood_group", d.blood_group);
                cmd.Parameters.AddWithValue("@image_name", d.image_name);


                int rows = cmd.ExecuteNonQuery();
                //row value will be greater than zero if it execute succesfully

                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            return isSuccess;
        }

        #endregion

        #region Update data in database 
        public bool Update(DonorBLL d)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();

            try
            {


                string sql = "Update Tbl_Donors set First_name=@First_name,Last_name = @Last_name,Email = @Email,Contact = @Contact,Gender =@Gender,Address = @Address,blood_group = @blood_group,Added_date=@Added_date,image_name=@image_name,Added_by = @Added_by where Donor_id = @Donor_id";
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@Last_name", d.Last_name);
                cmd.Parameters.AddWithValue("@Email", d.Email);
                cmd.Parameters.AddWithValue("@Added_by", d.Added_by);
                cmd.Parameters.AddWithValue("@First_name", d.First_name);
                cmd.Parameters.AddWithValue("@Contact", d.Contact);
                cmd.Parameters.AddWithValue("@Gender", d.Gender);
                cmd.Parameters.AddWithValue("@Address", d.Address);
                cmd.Parameters.AddWithValue("@Added_date", d.Added_date);
                cmd.Parameters.AddWithValue("@blood_group", d.blood_group);
                cmd.Parameters.AddWithValue("@image_name", d.image_name);
                cmd.Parameters.AddWithValue("@Donor_id", d.Donor_id);

                int rows = cmd.ExecuteNonQuery();
                //row value will be greater than zero if it execute succesfully

                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            return isSuccess;
        }
        #endregion

        #region Delete data from database 

        public bool Delete(DonorBLL d)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();
            try
            {
                string sql = "Delete from Tbl_Donors where Donor_id = @Donor_id";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@Donor_id", d.Donor_id);


                int rows = cmd.ExecuteNonQuery();
                //row value will be greater than zero if it execute succesfully

                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            return isSuccess;
        }
        #endregion

        #region Count the total donors
        public string countDonor(string blood_group)
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();

            string donors = "0";

            try
            {
                string sql = "select *from Tbl_Donors where blood_group = '" + blood_group + "'";
                SqlCommand cmd = new SqlCommand(sql, conn);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();
                adapter.Fill(dt);

                donors = dt.Rows.Count.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
            return donors;
        }
        #endregion

        #region   search the data from database
        public DataTable Search(string keywords)
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();

            DataTable dt = new DataTable();

            try
            {
                string sql = "select *from Tbl_Donors where Donor_id Like '%" + keywords + "%' OR Email Like '%" + keywords + "%'  OR First_name Like '%" + keywords + "%'OR Last_name Like '%" + keywords + "%' OR blood_group Like '%" + keywords + "%'  OR Address Like '%" + keywords + "%'";
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(dt);

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            return dt;

            {


            }
            #endregion
        }
        }
    }
