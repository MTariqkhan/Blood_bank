﻿using Blood_Bank_Mangement_System.BLL;
using Blood_Bank_Mangement_System.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blood_Bank_Mangement_System
{
    public partial class FormUser : Form
    {
        public FormUser()
        {
            InitializeComponent();
        }

        UsersBBL u = new UsersBBL();
        UserDAL dal = new UserDAL();
        string ImageName = "no-image.jpg";

        string rowheaderimage;

        string sourcePath = "";
        string destinationPath = "";


        private void User_Load(object sender, EventArgs e)
        {

            DataTable dt = dal.Select();
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
            string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));
            string ImagePath = paths + "\\Images\\no-image.jpg";

            ProfilePicture.Image = new Bitmap(ImagePath);
        }

        public void Clear()
        {
            
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox1.Text = "";




            string paths = Application.StartupPath.Substring(0, Application.StartupPath.Length - 10);
            string ImagePath = paths + "\\Images\\no-image.jpg";

            ProfilePicture.Image = new Bitmap(ImagePath);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Add function
            //get the value
            u.Full_name = textBox2.Text;
            u.Email = textBox3.Text;
            u.User_name = textBox4.Text;
            u.Password = textBox5.Text;
            u.Contact = textBox7.Text;
            u.Address = textBox6.Text;
            u.Added_date = DateTime.Now;
            u.Image_name = ImageName;

            if (ImageName != "no-image.jpg")
            {

                File.Copy(sourcePath, destinationPath);

               // MessageBox.Show("Imaged is Added SuccessFully");
            }
            //steps to adding value from ui to database 

            bool success = dal.Insert(u);
            if(success== true)
            {
                Clear();

                //display data in data gride view

                DataTable dt = dal.Select();
                dataGridView1.DataSource = dt;
                dataGridView1.Refresh();
                MessageBox.Show("New User is Added Successfully.");
            }
            else
            {
                MessageBox.Show("Fail to Add New User.");
            }
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex + 1 == dataGridView1.Rows.Count) return;
            DataGridViewRow abc = dataGridView1.Rows[e.RowIndex];
            textBox1.Text = abc.Cells[0].Value.ToString();
            textBox4.Text = abc.Cells[1].Value.ToString();
            textBox3.Text = abc.Cells[2].Value.ToString();
            textBox5.Text = abc.Cells[3].Value.ToString();
            textBox2.Text = abc.Cells[4].Value.ToString();
            textBox7.Text = abc.Cells[5].Value.ToString();
            textBox6.Text = abc.Cells[6].Value.ToString();
            ImageName     = abc.Cells[8].Value.ToString();

            rowheaderimage = ImageName;

            //change the image as per row clicked

            string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));
            if (ImageName != "no-image.jpg")
            {
               
                 
                string ImagePath = paths + "\\Images\\" + ImageName;

                ProfilePicture.Image = new Bitmap(ImagePath);

              
            }

            else
            {
                string ImagePath = paths + "\\Images\\no-image.jpg";

                ProfilePicture.Image = new Bitmap(ImagePath);


            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //update data
            u.User_id = int.Parse(textBox1.Text);
            u.Full_name = textBox2.Text;
            u.Email = textBox3.Text;
            u.User_name = textBox4.Text;
            u.Password = textBox5.Text;
            u.Contact = textBox7.Text;
            u.Address = textBox6.Text;
            u.Added_date = DateTime.Now;
            u.Image_name = ImageName;

            //data added or not 
            bool success = dal.Update(u);

            //update new image 
            if (ImageName == rowheaderimage)
            {

            }
            else
                {

            
                File.Copy(sourcePath, destinationPath);

                // MessageBox.Show("Imaged is Added SuccessFully");
            

            //remove the previous picture

            string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));

                string ImagePath = paths + "\\Images\\" + rowheaderimage;

                //clear function to clear all test boxes and pic box and gurbage function 
                Clear();

                GC.Collect();
                GC.WaitForPendingFinalizers();

                //function to del image

                File.Delete(ImagePath);
            }


            if (success == true)

            {
              
               
                DataTable dt = dal.Select();
                dataGridView1.DataSource = dt;

                dataGridView1.Refresh();
                MessageBox.Show("Data is Updated SuccessFully");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //delete
            u.User_id = int.Parse(textBox1.Text);

            if(rowheaderimage!= "no-image.jpg")
            {
                string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));

                string ImagePath = paths + "\\Images\\" + rowheaderimage;

                //clear function to clear all test boxes and oic box and gurbage function 
                Clear();

                GC.Collect();
                GC.WaitForPendingFinalizers();

                //function to del image

                File.Delete(ImagePath);
            }
            bool success = dal.Delete(u);
            
                if (success == true)
            {
                Clear();
                DataTable dt = dal.Select();
                dataGridView1.DataSource = dt;
                dataGridView1.Refresh();
                MessageBox.Show("Data is Deleted SuccessFully");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();


            //filter
            open.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;";

            if(open.ShowDialog()==DialogResult.OK)
            {
                if(open.CheckFileExists)
                {
                    ProfilePicture.Image = new Bitmap(open.FileName);

                    //rename the picture

                    string ext = Path.GetExtension(open.FileName);

                    //random name to pic
                    Random random = new Random();
                    int RandInt = random.Next(0, 1000);

                    //rename the image
                    ImageName = "Blood_Bank_MS_" + RandInt + ext;

                    //get the path of selected image
                     sourcePath = open.FileName;
                    string paths = Application.StartupPath.Substring(0, Application.StartupPath.Length - 10);
                   
                    //destination folder

                    destinationPath = paths + "\\Images\\" + ImageName;

                }
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            //search

            string keywords = textBox8.Text;

            if(keywords != null)
            {
                DataTable dt = dal.Search(keywords);
                dataGridView1.DataSource = dt;
            }
            else
            {
                DataTable dt = dal.Search(null);
                dataGridView1.DataSource = dt;
                
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
