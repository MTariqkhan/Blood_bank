﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Blood_Bank_Mangement_System.DAL;
using Blood_Bank_Mangement_System.UI;


namespace Blood_Bank_Mangement_System.UI
{
    public partial class Reset : Form
    {
        public Reset()
        {
            InitializeComponent();
        }

        Password_Reset U = new Password_Reset();

        private void button3_Click(object sender, EventArgs e)
        {


            string x1 = textBox1.Text;
            string x2 = textBox2.Text;
            string x3 = Password_Reset.E;



            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();

            try
            {
                string sql = "update Tbl_user set Password=@Password where Email=@Email";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@Password", x1);
                cmd.Parameters.AddWithValue("@Email", x3);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                int rows = cmd.ExecuteNonQuery();
                //row value will be greater than zero if it execute succesfully

                if (rows > 0)
                {
                    MessageBox.Show("Password Is Recovered Successfully");
                    FormLogin f = new FormLogin();
                    f.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Password Could Not Update");
                }
         
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }

            }
        
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
