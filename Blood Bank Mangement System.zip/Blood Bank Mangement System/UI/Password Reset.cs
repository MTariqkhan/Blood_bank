﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Blood_Bank_Mangement_System.BLL;
using Blood_Bank_Mangement_System.DAL;
using Blood_Bank_Mangement_System.UI;

namespace Blood_Bank_Mangement_System.UI
{
    public partial class Password_Reset : Form
    {
        public Password_Reset()
        {
            InitializeComponent();
        }



        public static string E;

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string user_name = textBox1.Text;
            string emails = textBox2.Text;
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();

            try
            {
                string sql = "select Email from Tbl_user where @User_name = User_name";

                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                cmd.Parameters.AddWithValue("@User_name", user_name);

                DataTable dt = new DataTable();
                adapter.Fill(dt);
                int rows = cmd.ExecuteNonQuery();

              
                string entry = dt.Rows[0][0].ToString();
            
                //row value will be greater than zero if it execute succesfully

              
         
                    if (entry == emails)
                    {
                        E = emails;
                      
                        Reset f = new Reset();
                        f.Show();
                        this.Hide();
                    }
                    else
                        MessageBox.Show("Please Enter Valid User_Name And Email");
                
          
        }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }


        
    }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
