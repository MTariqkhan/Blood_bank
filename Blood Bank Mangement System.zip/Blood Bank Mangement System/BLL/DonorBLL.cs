﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blood_Bank_Mangement_System.BLL
{
    class DonorBLL
    {
        public int Donor_id { get; set; }
        public string Email { get; set; }
        public string Last_name { get; set; }
        public string First_name { get; set; }
        public string Contact { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public DateTime Added_date { get; set; }
        public string image_name { get; set; }
       
        public string blood_group { get; set; }
        public int Added_by { get; set; }
    }
}
