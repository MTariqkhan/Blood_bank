﻿using Blood_Bank_Mangement_System.BLL;
using Blood_Bank_Mangement_System.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blood_Bank_Mangement_System.UI
{
    public partial class Donor : Form
    {
        public Donor()
        {
            InitializeComponent();
        }


        public void load()
        {
            
        }

        DonorBLL d = new DonorBLL();
        DonorDAL dal = new DonorDAL();
        string ImageName = "no-image.jpg";

        UserDAL udal = new UserDAL();
        string rowheaderimage;
        string sourcePath = "";
        string destinationPath = "";

        public void Clear()
        {
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            comboBox1.Text = "";
            comboBox2.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = " ";
            textBox1.Text = "";
            ImageName = "no-Image.jpg";

            string paths = Application.StartupPath.Substring(0, Application.StartupPath.Length - 10);
            string ImagePath = paths + "\\Images\\no-image.jpg";

            ProfilePicture.Image = new Bitmap(ImagePath);
        }
      

        private void Donor_Load(object sender, EventArgs e)
        {
            DataTable dt = dal.Select();
            dataGridView2.DataSource = dt;

            string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));
            string ImagePath = paths + "\\Images\\no-image.jpg";

           
            ProfilePicture.Image = new Bitmap(ImagePath);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Add Function

            

            //get the value
            d.First_name = textBox2.Text;
            d.Email = textBox4.Text;
            d.Last_name = textBox3.Text;
            d.Gender = comboBox1.Text;
            d.blood_group = comboBox2.Text;
            d.Contact = textBox7.Text;
            d.Address = textBox6.Text;
            String Loggedinuser = FormLogin.Loggedinuser;
            UsersBBL usr = udal.GetIDofUser(Loggedinuser);

            d.Added_by = usr.User_id;
            d.Added_date = DateTime.Now;
            d.image_name = ImageName;

            if (ImageName != "no-image.jpg")
            {

                File.Copy(sourcePath, destinationPath);

                // MessageBox.Show("Imaged is Added SuccessFully");
            }
            //steps to adding value from ui to database 

            bool success = dal.Insert(d);
            if (success == true)
            {
               
                //display data in data gride view

                Clear();

                DataTable dt = dal.Select();
                dataGridView2.DataSource = dt;
                this.dataGridView2.Refresh();
              
                MessageBox.Show("New Donor is Added Successfully.");



            }
            else
            {
                MessageBox.Show("Fail to Add New Donor.");
            }
            Refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //update data



            d.Donor_id = int.Parse(textBox1.Text);
            d.First_name = textBox2.Text;
            d.Email = textBox4.Text;
            d.Last_name = textBox3.Text;
            d.Gender = comboBox1.Text;
            d.blood_group = comboBox2.Text;
            d.Contact = textBox7.Text;
            d.Address = textBox6.Text;
            String Loggedinuser = FormLogin.Loggedinuser;
            UsersBBL usr = udal.GetIDofUser(Loggedinuser);

            d.Added_by = usr.User_id;
            d.image_name = ImageName;
            d.Added_date = DateTime.Now;

            //add the new one 

            bool success = dal.Update(d);
            if (ImageName == rowheaderimage)
            {


            }
            else
            {

                File.Copy(sourcePath, destinationPath);

                //data added or not 


                //remove the previous picture


                string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));

                string ImagePath = paths + "\\Images\\" + rowheaderimage;

                //clear function to clear all test boxes and pic box and gurbage function 
                Clear();


                GC.Collect();
                GC.WaitForPendingFinalizers();

                //function to del image

                File.Delete(ImagePath);
            }
            if (success == true)
            {
                Clear();
                DataTable dt = dal.Select();
                dataGridView2.DataSource = dt;
                this.dataGridView2.Refresh();

                MessageBox.Show("Data is Updated SuccessFully");

            }
                

            
        }
            private void dataGridView2_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
            {
                if (e.RowIndex + 1 == dataGridView2.Rows.Count) return;
                DataGridViewRow abc = dataGridView2.Rows[e.RowIndex];
                textBox1.Text = abc.Cells[0].Value.ToString();
                textBox2.Text = abc.Cells[1].Value.ToString();
                textBox3.Text = abc.Cells[2].Value.ToString();
                textBox4.Text = abc.Cells[3].Value.ToString();
                textBox7.Text = abc.Cells[4].Value.ToString();
                comboBox1.Text = abc.Cells[5].Value.ToString();
                textBox6.Text = abc.Cells[6].Value.ToString();
                comboBox2.Text = abc.Cells[7].Value.ToString();

                ImageName = abc.Cells[9].Value.ToString();

                rowheaderimage = ImageName;

                //change the image as per row clicked

                string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));

                string ImagePath = paths + "\\Images\\" + ImageName;

                ProfilePicture.Image = new Bitmap(ImagePath);

            }
        
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();


            //filter
            open.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;";

            if (open.ShowDialog() == DialogResult.OK)
            {
                if (open.CheckFileExists)
                {
                    ProfilePicture.Image = new Bitmap(open.FileName);

                    //rename the picture

                    string ext = Path.GetExtension(open.FileName);

                    //random name to pic
                    Random random = new Random();
                    int RandInt = random.Next(0, 1000);

                    //rename the image
                    ImageName = "Blood_Bank_MS_" + RandInt + ext;

                    //get the path of selected image
                    sourcePath = open.FileName;
                    string paths = Application.StartupPath.Substring(0, Application.StartupPath.Length - 10);

                    //destination folder

                    destinationPath = paths + "\\Images\\" + ImageName;

                  




                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {       
            //delete function

            d.Donor_id = int.Parse(textBox1.Text);

            if (rowheaderimage != "no-image.jpg")
            {
                string paths = Application.StartupPath.Substring(0, (Application.StartupPath.Length - 10));

                string ImagePath = paths + "\\Images\\" + rowheaderimage;

                //clear function to clear all test boxes and pic box and gurbage function 
                Clear();

                GC.Collect();
                GC.WaitForPendingFinalizers();

                //function to del image

                File.Delete(ImagePath);

                bool success = dal.Delete(d);
                {
                    if (success == true)

                        Clear();

                    dataGridView2.Refresh();
                    DataTable dt = dal.Select();
                    dataGridView2.DataSource = dt;
                    MessageBox.Show("Data is Deleted SuccessFully");

                }
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

            //search 
            string keywords = textBox8.Text;

            if (keywords != null)
            {
                DataTable dt = dal.Search(keywords);
                dataGridView2.DataSource = dt;
            }
            else
            {
                DataTable dt = dal.Search(null);
                dataGridView2.DataSource = dt;


            }
        }
    }
}
