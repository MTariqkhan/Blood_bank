﻿using Blood_Bank_Mangement_System.BLL;
using Blood_Bank_Mangement_System.DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blood_Bank_Mangement_System.UI
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        LoginBLL l = new LoginBLL();
        LoginDAL dal = new LoginDAL();

       public static string Loggedinuser;
        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //code to log in in application
            l.User_name = textBox1.Text;
            l.Password = textBox2.Text;

            //check the user log in or not
            bool Success = dal.LoginCheck(l);

            if(Success == true)
            {
               // MessageBox.Show("Log In SUccessFully");

                //save the user in Static Method

                Loggedinuser = l.User_name;

                FormHome f = new FormHome();
                f.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Log In Failed , try Again");
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Password_Reset f = new Password_Reset();
            f.Show();
            this.Hide();
        }
    }
}
