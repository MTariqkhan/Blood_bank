﻿using Blood_Bank_Mangement_System.BLL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blood_Bank_Mangement_System.DAL
{

    class LoginDAL
    {

        #region Update Password in database

        public bool LoginCheck(LoginBLL l)
        {
            bool Success = false;

            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();

            try
            {
                string sql = "Select *From Tbl_user where User_name= @User_name AND Password = @Password";
                SqlCommand cmd = new SqlCommand(sql, conn);


                cmd.Parameters.AddWithValue("@User_name", l.User_name);

                cmd.Parameters.AddWithValue("@Password", l.Password);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);


                DataTable dt = new DataTable();
                adapter.Fill(dt);

                // check wheather user exist or not 

                if (dt.Rows.Count > 0)
                {
                    Success = true;
                }
                else
                {
                    Success = false;
                }
            }
            //For Exceptiopnal Error
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            return Success;
        }


        #endregion
        #region Update data in database 
        public bool UpdatePassword(LoginBLL u)
        {
            bool isSuccess = false;
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-4NDKQFM\\SQLEXPRESS;Initial Catalog=BloodBankManagementSystem;Integrated Security=True");
            conn.Open();

            try
            {
                string sql = "update Tbl_user set Password=@Password where User_name= @User_name AND Email = @Email";
                SqlCommand cmd = new SqlCommand(sql, conn);

                cmd.Parameters.AddWithValue("@User_name", u.User_name);
                cmd.Parameters.AddWithValue("@Email", u.Email);
                cmd.Parameters.AddWithValue("@Password", u.Password);
               

                int rows = cmd.ExecuteNonQuery();
                //row value will be greater than zero if it execute succesfully

                if (rows > 0)
                {
                    isSuccess = true;
                }
                else
                {
                    isSuccess = false;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();

            }
            return isSuccess;
        }
        #endregion
    }

}