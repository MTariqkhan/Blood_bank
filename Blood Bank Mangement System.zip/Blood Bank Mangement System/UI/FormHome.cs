﻿using Blood_Bank_Mangement_System.DAL;
using Blood_Bank_Mangement_System.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blood_Bank_Mangement_System
{
    public partial class FormHome : Form
    {
        public FormHome()
        {
            InitializeComponent();
        }

        DonorDAL dal = new DonorDAL();
        private void FormHome_Load(object sender, EventArgs e)
        {
            alldonorcount();
           
            DataTable dt = dal.Select();
            dgvDonors.DataSource = dt;
            dgvDonors.Refresh();

            //display username logged in user
            lbluse.Text = FormLogin.Loggedinuser;
        }
        public void alldonorcount()
        {
            label5.Text = dal.countDonor("O+");
            label8.Text = dal.countDonor("O-");
            label14.Text = dal.countDonor("A+");
            label11.Text = dal.countDonor("A-");
            label26.Text = dal.countDonor("B+");
            label20.Text = dal.countDonor("B-");
            label23.Text = dal.countDonor("AB+");
            label17.Text = dal.countDonor("AB-");



        }

        private void menuStriptop_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //open user form
            FormUser use = new FormUser();
            use.Show();
            // this.Hide();
        }

        private void donorsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Donor d = new Donor();
            d.Show();
        }

        private void FormHome_Activated(object sender, EventArgs e)
        {
            alldonorcount();
        }

        private void txtsearch_TextChanged(object sender, EventArgs e)
        {
            string keywords = txtsearch.Text;

            if (keywords != null)
            {
                DataTable dt = dal.Search(keywords);
                dgvDonors.DataSource = dt;
            }
            else
            {
                DataTable dt = dal.Search(null);
                dgvDonors.DataSource = dt;
            }
        }

        private void lbluse_Click(object sender, EventArgs e)
        {

        }
    }
}